package com.example.myapp

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.cp3.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Referenciando os botões no layout
        val button1 = findViewById<Button>(R.id.button1)
        val button2 = findViewById<Button>(R.id.button2)
        val button3 = findViewById<Button>(R.id.button3)
        val button4 = findViewById<Button>(R.id.button4)


        button1.setOnClickListener {
            Toast.makeText(this, "Serviço 1 acionado", Toast.LENGTH_SHORT).show()

        }


        button2.setOnClickListener {
            Toast.makeText(this, "Serviço 2 acionado", Toast.LENGTH_SHORT).show()

        }


        button3.setOnClickListener {
            Toast.makeText(this, "Serviço 3 acionado", Toast.LENGTH_SHORT).show()

        }


        button4.setOnClickListener {
            Toast.makeText(this, "Serviço 4 acionado", Toast.LENGTH_SHORT).show()

        }
    }
}